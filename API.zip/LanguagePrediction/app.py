from flask import Flask, render_template, request
import os
import joblib
import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt
import pickle
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from sklearn import linear_model
import seaborn as sbs
from sklearn import feature_extraction
from sklearn.linear_model import LogisticRegression

app = Flask(__name__)
model = pickle.load(open('./models/filename.pkl', 'rb'))

names_gen=pd.read_csv(r"C:\Users\vinaydeekshitGarimel\Downloads\project\names_data_autogen_full - Copy.csv")
a = names_gen.sample(frac = 1,random_state=42)
b = a.dropna(how='all').dropna(how='all',axis=1)

df2 = b.drop(['Sno', 'Middle Name', 'Language_Main'], axis=1)

@app.route('/')
def index():
   return render_template('index.html')	


@app.route('/predict', methods = ['POST'])
def predict():
   fname = request.form.get('fname')
   sname = request.form.get('sname')

   df2.loc[len(df2)] = [fname, sname]
   print(df2[len(df2)-1])
   data = pd.get_dummies(df2)

   return render_template('results.html', res=df2[len(df2)-1])

if __name__ == '__main__':
   app.run(debug = True)